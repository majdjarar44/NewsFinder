package com.mcit.newsfinder.ui.fragment.news

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.mcit.newsfinder.usecase.Resource
import com.mcit.newsfinder.data.model.main.MainNews
import com.mcit.newsfinder.data.repository.MainNewsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import javax.inject.Inject


@HiltViewModel
class MainNewsViewModel @Inject constructor(val repo: MainNewsRepository): ViewModel() {
    val data=MutableLiveData<Resource<MainNews>>()
    private val viewModelJob = SupervisorJob()
    private val uiScope = CoroutineScope(Dispatchers.IO + viewModelJob)


    init {
        majd()
    }

    override fun onCleared() {

        super.onCleared()
        viewModelJob.cancel()
    }


      fun majd() {

          uiScope.launch {
              data.postValue(repo.getMainNews()) // happens on the background
          }

      }



}