package com.mcit.newsfinder.data.repository

import com.mcit.newsfinder.data.AppService
import com.mcit.newsfinder.usecase.BaseDataSource
import javax.inject.Inject

class MainNewsRepository @Inject constructor(val appService: AppService) : BaseDataSource() {
    suspend fun getMainNews() = getResult {
        appService.getSession()
    }
}