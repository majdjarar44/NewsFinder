package com.mcit.newsfinder.di

import android.content.Context
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.mcit.newsfinder.BuildConfig

import com.mcit.newsfinder.data.AppService
import com.mcit.newsfinder.data.repository.DataService
import com.mcit.newsfinder.utils.Qualifier
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Named
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton //This will differentiate retrofit object
    fun retrofitAuth(
        client: OkHttpClient,
        gsonConverterFactory: GsonConverterFactory
    ): Retrofit =
        Retrofit.Builder()
            .client(client)
            .addConverterFactory(gsonConverterFactory)
            .baseUrl(BuildConfig.BASE_URl).build()




    //Build Api services with respect to qualifiers

    @Provides
    @Singleton
    fun authApiService( retrofit: Retrofit): AppService = retrofit.create(AppService::class.java)
//
//
//    @Provides
//    @Singleton
//    fun settingApiService(@Qualifier.Data retrofit: Retrofit): DataService = retrofit.create(DataService::class.java)
//

    @Provides
    fun provideGson(): Gson = GsonBuilder().create()


//    @Provides
//    fun provideMainNewsService(retrofit: Retrofit): AppService =
//        retrofit.create(AppService::class.java)

    @Provides
    @Singleton
    fun getLanguageHeaderOkHttpClient(): OkHttpClient {
        val builder = OkHttpClient.Builder()
        builder.addInterceptor(HttpLoggingInterceptor().apply {
            this.level = HttpLoggingInterceptor.Level.HEADERS
            this.level = HttpLoggingInterceptor.Level.BODY
        })
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
        return builder.build()
    }
}