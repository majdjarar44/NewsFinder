package com.mcit.newsfinder.data.model.main

data class Source(
    val id: Any,
    val name: String
)