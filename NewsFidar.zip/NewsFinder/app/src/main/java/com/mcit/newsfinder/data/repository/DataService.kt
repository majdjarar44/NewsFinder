package com.mcit.newsfinder.data.repository

interface DataService {
}