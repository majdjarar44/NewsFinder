package com.mcit.newsfinder.utils

class Qualifier {
    @javax.inject.Qualifier
    @Retention(AnnotationRetention.BINARY)
    annotation class Main

    @javax.inject.Qualifier
    @Retention(AnnotationRetention.BINARY)
    annotation class Data
}