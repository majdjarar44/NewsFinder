package com.mcit.newsfinder.ui.fragment.news

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.mcit.newsfinder.data.model.main.Article
import com.mcit.newsfinder.databinding.FragmentMainNewsBinding
import com.mcit.newsfinder.global.BaseFragment
import com.mcit.newsfinder.usecase.Resource
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainNewsFragment : BaseFragment() {

    private lateinit var binding: FragmentMainNewsBinding
    private val viewModel: MainNewsViewModel by viewModels()

    override fun layoutResource(inflater: LayoutInflater, container: ViewGroup?): View {
        binding = FragmentMainNewsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        swipeRefreshLayout()
        observeNewNews()
    }

    private fun observeNewNews() {
        viewModel.data.observe(viewLifecycleOwner, Observer {
            if (it.status == Resource.Status.SUCCESS) {
                setArticlesInAdapter(it.data?.articles)
            }else{
                showFailedMessage(it.message.toString())
            }
        })
    }

    private fun setArticlesInAdapter(articles: ArrayList<Article>?) {
        binding.recMainNews.adapter = MainNewsAdapter(articles!!) {
            val url = it?.url
            val i = Intent(Intent.ACTION_VIEW)
            i.data = Uri.parse(url)
            startActivity(i)
        }
        val layoutManager = LinearLayoutManager(requireContext())
        binding.recMainNews.layoutManager = layoutManager
    }

    private fun swipeRefreshLayout() {
        binding?.srRefreshLayout?.setOnRefreshListener {
            binding?.srRefreshLayout?.isRefreshing = false
            viewModel.majd()
        }
    }
}