package com.mcit.newsfinder.ui.fragment.news

import android.view.ViewGroup
import android.widget.ImageView
import androidx.core.net.toUri
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide
import com.dominate.talabyeh.app.core.base.BaseAdapter
import com.mcit.newsfinder.global.BaseBindingViewHolder
import com.mcit.newsfinder.data.model.main.Article
import com.mcit.newsfinder.databinding.CellMainNewsBinding

class MainNewsAdapter(
    private val mainNews: ArrayList<Article>,
    private val onclickListener: ((Article?) -> Unit),
) : BaseAdapter<Article, MainNewsAdapter.ViewHolder>(mainNews) {
    override fun getViewHolder(parent: ViewGroup, viewType: Int): MainNewsAdapter.ViewHolder {
        val binding = CellMainNewsBinding.inflate(inflater, parent, false)
        return ViewHolder(binding)
    }

    inner class ViewHolder(val binding: CellMainNewsBinding) :
        BaseBindingViewHolder<Article>(binding) {
        override fun bind(position: Int, item: Article?) {
            binding.artical = item
            setImageUrl(binding.imageView,item?.urlToImage)
            binding.root.setOnClickListener {
                onclickListener(item)
                notifyDataSetChanged()
            }
        }
    }
    @BindingAdapter("imageUrl")
    fun setImageUrl(imgView: ImageView, imgUrl: String?) {
        imgUrl?.let {
            val imgUri = it.toUri().buildUpon().scheme("http").build()
            Glide.with(imgView.context)
                .load(imgUri)
                .into(imgView)

        }
    }
}
