package com.mcit.newsfinder.ui.fragment.details

import androidx.lifecycle.ViewModel
import javax.inject.Inject

//class DetailsNewViewModel @Inject constructor(): ViewModel()
//{
//
//}